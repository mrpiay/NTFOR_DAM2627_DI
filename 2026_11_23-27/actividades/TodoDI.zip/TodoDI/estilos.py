# La hoja de estilo de TodoDI: el aspecto de cada control, en el lenguaje QSS de Qt.
# Cada regla empieza por # y el nombre del control (su objectName), y entre llaves sus propiedades.
ESTILO = """
#campo {
    background-color: white;
}
#boton_anadir {
    background-color: royalblue;
    color: white;
    border: none;
    padding: 6px;
}
#lista {
    background-color: lightgray;
}
#boton_eliminar {
    background-color: red;
    color: white;
    border: none;
    padding: 6px;
}
#boton_eliminar:disabled {
    background-color: lightcoral;
}
"""
