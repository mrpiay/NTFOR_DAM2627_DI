from PySide6.QtWidgets import QApplication
import bd
from ventana import VentanaTodo
bd.crear_bd()
app = QApplication()
ventana = VentanaTodo()
ventana.show()
app.exec()
