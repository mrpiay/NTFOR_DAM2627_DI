import sqlite3
RUTA = "tareas.db"
def ejecutar_sql(sql, valores=()):
    # Abre la conexión con la base de datos (si el archivo no existe, lo crea)
    conexion = sqlite3.connect(RUTA)
    # Ejecuta la consulta, con los valores en el lugar de los ?
    cursor = conexion.execute(sql, valores)
    # Lee todas las filas del resultado ([] si la consulta no devuelve filas)
    filas = cursor.fetchall()
    # Confirma los cambios: sin esto, no se guardan
    conexion.commit()
    # Cierra la conexión
    conexion.close()
    return filas
def crear_bd():
    # Crea la tabla, si no existe: un id que se numera solo y el texto de la tarea
    ejecutar_sql("CREATE TABLE IF NOT EXISTS tareas (id INTEGER PRIMARY KEY AUTOINCREMENT, texto TEXT NOT NULL)")
def insertar_tarea(texto):
    # Guarda una tarea nueva; el texto va en el ?
    ejecutar_sql("INSERT INTO tareas (texto) VALUES (?)", (texto,))
def obtener_tareas():
    # Devuelve una tupla (id, texto) por tarea, en el orden en que se añadieron
    return ejecutar_sql("SELECT id, texto FROM tareas ORDER BY id")
def eliminar_tarea(id_tarea):
    # Borra solo la tarea con ese id
    ejecutar_sql("DELETE FROM tareas WHERE id = ?", (id_tarea,))
