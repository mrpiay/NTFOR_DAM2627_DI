from PySide6.QtCore import Qt
from PySide6.QtWidgets import QLineEdit, QListWidget, QListWidgetItem, QPushButton, QVBoxLayout, QWidget
import bd
import estilos
class VentanaTodo(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TodoDI")
        self.resize(400, 300)
        # Los controles, de arriba abajo
        self.campo = QLineEdit()
        self.boton_anadir = QPushButton("Añadir tarea")
        self.lista = QListWidget()
        self.boton_eliminar = QPushButton("Eliminar tarea")
        # El nombre de cada control, para que la hoja de estilo sepa a cuál se refiere cada regla
        self.campo.setObjectName("campo")
        self.boton_anadir.setObjectName("boton_anadir")
        self.lista.setObjectName("lista")
        self.boton_eliminar.setObjectName("boton_eliminar")
        # Los colores: la hoja de estilo de estilos.py se aplica a la ventana y a todo lo que contiene
        self.setStyleSheet(estilos.ESTILO)
        # La distribución: uno debajo de otro, en este orden
        capa = QVBoxLayout(self)
        capa.addWidget(self.campo)
        capa.addWidget(self.boton_anadir)
        capa.addWidget(self.lista)
        capa.addWidget(self.boton_eliminar)
        # Las señales: qué método se ejecuta con cada acción
        self.boton_anadir.clicked.connect(self.anadir_tarea)
        self.boton_eliminar.clicked.connect(self.eliminar_tarea)
        self.lista.itemSelectionChanged.connect(self.actualizar_boton_eliminar)
        # Las tareas guardadas, al abrir
        self.cargar_tareas()
    def cargar_tareas(self):
        # Vacía la lista, para no repetir las tareas que ya estaban
        self.lista.clear()
        # Cada tarea llega como una tupla (id, texto), que se reparte en dos variables
        for id_tarea, texto in bd.obtener_tareas():
            # Una fila nueva con el texto que se ve (DisplayRole)
            elemento = QListWidgetItem(texto)
            # En la casilla oculta de la fila (UserRole), el id de la tarea
            elemento.setData(Qt.ItemDataRole.UserRole, id_tarea)
            self.lista.addItem(elemento)
        # Después de cargar no hay ninguna tarea elegida: el botón se desactiva
        self.actualizar_boton_eliminar()
    def actualizar_boton_eliminar(self):
        # selectedItems() devuelve las filas elegidas: una lista vacía si no hay ninguna
        hay_seleccion = len(self.lista.selectedItems()) > 0
        # True activa el botón; False lo desactiva
        self.boton_eliminar.setEnabled(hay_seleccion)
    def anadir_tarea(self):
        # El texto escrito, sin espacios al principio ni al final
        texto = self.campo.text().strip()
        # Solo si hay algo escrito
        if texto:
            bd.insertar_tarea(texto)
            # Se vuelve a cargar, para que la fila nueva lleve el id que le ha dado la base de datos
            self.cargar_tareas()
            self.campo.clear()
    def eliminar_tarea(self):
        # La fila elegida (siempre hay una: si no, el botón estaría desactivado)
        elemento = self.lista.selectedItems()[0]
        # El id guardado en su casilla oculta (UserRole)
        id_tarea = elemento.data(Qt.ItemDataRole.UserRole)
        # Se borra de la base de datos
        bd.eliminar_tarea(id_tarea)
        # Y se vuelve a cargar la lista, ya sin ella
        self.cargar_tareas()
