"""Pruebas de los gestos, sin cámara: se llama a aplicar_gesto como si el gesto
lo hubiera enviado el detector.

Ejecuta desde la carpeta del proyecto:  python -m pytest -v
"""
import pytest

import almacen
from ventana_gestos import VentanaConGestos


@pytest.fixture
def ventana(qtbot, tmp_path, monkeypatch):
    # Una base de datos nueva en una carpeta temporal: valora.db no se toca
    monkeypatch.setattr(almacen, "RUTA_BD", tmp_path / "prueba.db")
    almacen.crear_bd()
    v = VentanaConGestos()
    qtbot.addWidget(v)
    return v


def test_pulgar_arriba_y_pulgar_abajo(ventana):
    ventana.aplicar_gesto("Thumb_Up")
    ventana.aplicar_gesto("Thumb_Up")
    assert ventana.ui.selDocente.nota == 2
    ventana.aplicar_gesto("Thumb_Down")
    assert ventana.ui.selDocente.nota == 1


def test_palma_abierta_guarda_solo_con_las_tres_notas(ventana):
    ventana.aplicar_gesto("Open_Palm")
    assert almacen.leer_valoras() == []
    for selector in (ventana.ui.selDocente, ventana.ui.selMateriales, ventana.ui.selClases):
        selector.nota = 4
    ventana.aplicar_gesto("Open_Palm")
    assert len(almacen.leer_valoras()) == 1


def test_la_opcion_del_menu(ventana):
    assert ventana.accion_gestos in ventana.ui.menuValora.actions()
    assert ventana.accion_gestos.isCheckable()
    assert ventana.accion_gestos.shortcut().toString() == "Ctrl+G"
