"""La ventana de ValoraDI con gestos de la mano (paso 10).

VentanaConGestos hereda de VentanaPrincipal: es la misma ventana, con todo lo que ya
hace, y le añade los gestos. ventana.py no se toca. Los gestos los reconoce
DetectorGestos (gestos.py), con el modelo ya entrenado de MediaPipe.

Gestos, sobre la categoría que tiene el foco:
    pulgar arriba  → una estrella más
    pulgar abajo   → una estrella menos
    victoria       → la categoría siguiente
    palma abierta  → guardar la valoración, si están las tres notas
Para repetir el mismo gesto, se baja la mano y se vuelve a hacer.
"""
from PySide6.QtGui import QAction, QKeySequence
from PySide6.QtWidgets import QMessageBox

import gestos
from modelo import CATEGORIAS, NOMBRES
from ventana import VentanaPrincipal


class VentanaConGestos(VentanaPrincipal):
    def __init__(self):
        super().__init__()          # la ventana de siempre: el diseño, las conexiones y el resumen

        # ── El detector: avisa con una señal de cada gesto nuevo ─────────
        self.detector = gestos.DetectorGestos(self)
        self.detector.gestoDetectado.connect(self.aplicar_gesto)
        self.detector.error.connect(self.avisar_error)

        # ── Una opción nueva en el menú, marcable y con atajo ────────────
        # Marcada, la cámara está encendida; desmarcada, apagada
        self.accion_gestos = QAction("Gestos de la mano", self)
        self.accion_gestos.setCheckable(True)
        self.accion_gestos.setShortcut(QKeySequence("Ctrl+G"))
        self.accion_gestos.toggled.connect(self.activar_gestos)
        self.ui.menuValora.insertAction(self.ui.actionSalir, self.accion_gestos)   # antes de «Salir»

    # ── Encender y apagar la cámara ──────────────────────────────────────
    def activar_gestos(self, activar):
        if not activar:
            self.detector.detener()
            self.ui.statusbar.showMessage("Gestos desactivados", 3000)
        elif self.detector.iniciar():
            self.ui.statusbar.showMessage(
                "Gestos activados: pulgar arriba o abajo, victoria para cambiar de categoría "
                "y palma abierta para guardar")
        else:
            self.accion_gestos.setChecked(False)    # no se ha podido: la opción se desmarca

    def avisar_error(self, mensaje):
        QMessageBox.warning(self, "Gestos de la mano", mensaje)

    # ── Qué hace cada gesto ──────────────────────────────────────────────
    def categoria_activa(self):
        """La categoría cuyas estrellas tienen el foco; si no lo tiene ninguna, la primera."""
        foco = self.focusWidget()
        for categoria in CATEGORIAS:
            if self.selectores[categoria] is foco:
                return categoria
        return CATEGORIAS[0]

    def aplicar_gesto(self, gesto):
        categoria = self.categoria_activa()
        selector = self.selectores[categoria]
        if gesto == "Thumb_Up":
            selector.nota = max(1, selector.nota + 1)       # como la flecha derecha
        elif gesto == "Thumb_Down":
            selector.nota = max(1, selector.nota - 1)       # como la flecha izquierda
        elif gesto == "Victory":
            # La siguiente categoría; después de la última, vuelve a la primera (%)
            categoria = CATEGORIAS[(CATEGORIAS.index(categoria) + 1) % len(CATEGORIAS)]
            selector = self.selectores[categoria]
            selector.setFocus()
        elif gesto == "Open_Palm":
            if self.ui.btnGuardar.isEnabled():
                self.guardar()                              # dice «Valoración guardada»
            else:
                self.ui.statusbar.showMessage("Palma abierta: faltan notas para guardar", 3000)
            return
        else:
            return                                          # los demás gestos no hacen nada
        # Lo que ha entendido la app, para que se vea que el gesto ha llegado
        nota = f"{selector.nota} de 5" if selector.nota else "sin nota"
        self.ui.statusbar.showMessage(f"{gestos.NOMBRES[gesto].capitalize()}: {NOMBRES[categoria]}, {nota}", 3000)

    # ── Al cerrar la ventana, la cámara se apaga ─────────────────────────
    def closeEvent(self, evento):
        self.detector.detener()
        super().closeEvent(evento)
