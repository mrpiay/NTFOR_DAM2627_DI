"""Diálogo modal «Pesos»: cuánto cuenta cada categoría en la nota global."""
from PySide6.QtWidgets import QDialog, QDialogButtonBox, QFormLayout, QLabel, QSpinBox

from modelo import CATEGORIAS, NOMBRES, Pesos


class DialogoPesos(QDialog):
    """Pide los tres pesos, en %. «Aceptar» solo se activa si suman 100."""

    def __init__(self, pesos, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Pesos de la nota global")

        # ── Un campo por categoría, de 0 a 100 % ─────────────────────────
        formulario = QFormLayout(self)
        self._campos = {}
        for categoria in CATEGORIAS:
            campo = QSpinBox()
            campo.setRange(0, 100)
            campo.setSingleStep(5)
            campo.setSuffix(" %")
            campo.setValue(pesos.peso(categoria))
            campo.setAccessibleName(f"Peso de {NOMBRES[categoria].lower()}")
            campo.valueChanged.connect(self._comprobar)
            # addRow(texto, campo) crea la etiqueta y la une al campo (buddy): Alt+letra lleva al campo
            formulario.addRow(f"&{NOMBRES[categoria]}:", campo)
            self._campos[categoria] = campo

        # ── El aviso: cuánto falta o sobra para 100 % ────────────────────
        self._aviso = QLabel()
        self._aviso.setStyleSheet("color: #B00020;")   # rojo oscuro: buen contraste sobre fondo claro
        # Sitio reservado desde el principio para el aviso más largo (los tres pesos al 100 %),
        # para que el diálogo no cambie de tamaño al aparecer o cambiar el mensaje
        medidas = self._aviso.fontMetrics()
        self._aviso.setMinimumSize(medidas.horizontalAdvance(Pesos(100, 100, 100).aviso), medidas.height())
        formulario.addRow(self._aviso)

        # ── Aceptar y Cancelar ───────────────────────────────────────────
        self._botones = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        # Qt los escribe en inglés («OK», «Cancel») si no se le dice otra cosa
        self._botones.button(QDialogButtonBox.Ok).setText("Aceptar")
        self._botones.button(QDialogButtonBox.Cancel).setText("Cancelar")
        self._botones.accepted.connect(self.accept)
        self._botones.rejected.connect(self.reject)
        formulario.addRow(self._botones)

        self._comprobar()

    def pesos(self):
        """Los pesos que hay escritos ahora en el diálogo."""
        return Pesos(*(self._campos[c].value() for c in CATEGORIAS))

    def _comprobar(self):
        # El modelo dice si son válidos y qué falta; el diálogo solo lo muestra
        pesos = self.pesos()
        self._aviso.setText(pesos.aviso)
        self._botones.button(QDialogButtonBox.Ok).setEnabled(pesos.validos)
