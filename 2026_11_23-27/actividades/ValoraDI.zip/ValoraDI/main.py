"""ValoraDI: valoraciones anónimas de docente, materiales y clases, con nota global ponderada.

Se ejecuta desde la carpeta del proyecto, con el entorno virtual activado:
    python main.py
"""
import sys

from PySide6.QtWidgets import QApplication

import almacen
from ventana_gestos import VentanaConGestos       # paso 10: la ventana con gestos


def main():
    almacen.crear_bd()                 # crea las tablas la primera vez
    app = QApplication(sys.argv)
    ventana = VentanaConGestos()
    ventana.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
