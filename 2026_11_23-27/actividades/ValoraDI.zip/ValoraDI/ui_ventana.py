# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ventana.ui'
##
## Created by: Qt User Interface Compiler version 6.12.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QApplication, QFormLayout, QGridLayout, QGroupBox,
    QHBoxLayout, QLabel, QMainWindow, QMenu,
    QMenuBar, QPushButton, QSizePolicy, QSpacerItem,
    QStatusBar, QVBoxLayout, QWidget)

from selector_nota import SelectorNota

class Ui_VentanaPrincipal(object):
    def setupUi(self, VentanaPrincipal):
        if not VentanaPrincipal.objectName():
            VentanaPrincipal.setObjectName(u"VentanaPrincipal")
        VentanaPrincipal.resize(480, 460)
        self.actionGuardar = QAction(VentanaPrincipal)
        self.actionGuardar.setObjectName(u"actionGuardar")
        self.actionGuardar.setEnabled(False)
        self.actionPesos = QAction(VentanaPrincipal)
        self.actionPesos.setObjectName(u"actionPesos")
        self.actionSalir = QAction(VentanaPrincipal)
        self.actionSalir.setObjectName(u"actionSalir")
        self.centralwidget = QWidget(VentanaPrincipal)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.grpNueva = QGroupBox(self.centralwidget)
        self.grpNueva.setObjectName(u"grpNueva")
        self.verticalLayout_2 = QVBoxLayout(self.grpNueva)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.formNotas = QFormLayout()
        self.formNotas.setObjectName(u"formNotas")
        self.lblDocente = QLabel(self.grpNueva)
        self.lblDocente.setObjectName(u"lblDocente")

        self.formNotas.setWidget(0, QFormLayout.ItemRole.LabelRole, self.lblDocente)

        self.selDocente = SelectorNota(self.grpNueva)
        self.selDocente.setObjectName(u"selDocente")
        self.selDocente.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        self.formNotas.setWidget(0, QFormLayout.ItemRole.FieldRole, self.selDocente)

        self.lblMateriales = QLabel(self.grpNueva)
        self.lblMateriales.setObjectName(u"lblMateriales")

        self.formNotas.setWidget(1, QFormLayout.ItemRole.LabelRole, self.lblMateriales)

        self.selMateriales = SelectorNota(self.grpNueva)
        self.selMateriales.setObjectName(u"selMateriales")
        self.selMateriales.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        self.formNotas.setWidget(1, QFormLayout.ItemRole.FieldRole, self.selMateriales)

        self.lblClases = QLabel(self.grpNueva)
        self.lblClases.setObjectName(u"lblClases")

        self.formNotas.setWidget(2, QFormLayout.ItemRole.LabelRole, self.lblClases)

        self.selClases = SelectorNota(self.grpNueva)
        self.selClases.setObjectName(u"selClases")
        self.selClases.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        self.formNotas.setWidget(2, QFormLayout.ItemRole.FieldRole, self.selClases)


        self.verticalLayout_2.addLayout(self.formNotas)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.espacioGuardar = QSpacerItem(0, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.espacioGuardar)

        self.btnGuardar = QPushButton(self.grpNueva)
        self.btnGuardar.setObjectName(u"btnGuardar")
        self.btnGuardar.setAutoDefault(True)
        self.btnGuardar.setEnabled(False)

        self.horizontalLayout.addWidget(self.btnGuardar)


        self.verticalLayout_2.addLayout(self.horizontalLayout)


        self.verticalLayout.addWidget(self.grpNueva)

        self.grpResumen = QGroupBox(self.centralwidget)
        self.grpResumen.setObjectName(u"grpResumen")
        self.gridResumen = QGridLayout(self.grpResumen)
        self.gridResumen.setObjectName(u"gridResumen")
        self.lblTotal = QLabel(self.grpResumen)
        self.lblTotal.setObjectName(u"lblTotal")

        self.gridResumen.addWidget(self.lblTotal, 0, 0, 1, 1)

        self.btnPesos = QPushButton(self.grpResumen)
        self.btnPesos.setObjectName(u"btnPesos")
        self.btnPesos.setAutoDefault(True)

        self.gridResumen.addWidget(self.btnPesos, 0, 2, 1, 1)

        self.lblNombreDocente = QLabel(self.grpResumen)
        self.lblNombreDocente.setObjectName(u"lblNombreDocente")

        self.gridResumen.addWidget(self.lblNombreDocente, 1, 0, 1, 1)

        self.lblMediaDocente = QLabel(self.grpResumen)
        self.lblMediaDocente.setObjectName(u"lblMediaDocente")

        self.gridResumen.addWidget(self.lblMediaDocente, 1, 1, 1, 1)

        self.lblPesoDocente = QLabel(self.grpResumen)
        self.lblPesoDocente.setObjectName(u"lblPesoDocente")

        self.gridResumen.addWidget(self.lblPesoDocente, 1, 2, 1, 1)

        self.lblNombreMateriales = QLabel(self.grpResumen)
        self.lblNombreMateriales.setObjectName(u"lblNombreMateriales")

        self.gridResumen.addWidget(self.lblNombreMateriales, 2, 0, 1, 1)

        self.lblMediaMateriales = QLabel(self.grpResumen)
        self.lblMediaMateriales.setObjectName(u"lblMediaMateriales")

        self.gridResumen.addWidget(self.lblMediaMateriales, 2, 1, 1, 1)

        self.lblPesoMateriales = QLabel(self.grpResumen)
        self.lblPesoMateriales.setObjectName(u"lblPesoMateriales")

        self.gridResumen.addWidget(self.lblPesoMateriales, 2, 2, 1, 1)

        self.lblNombreClases = QLabel(self.grpResumen)
        self.lblNombreClases.setObjectName(u"lblNombreClases")

        self.gridResumen.addWidget(self.lblNombreClases, 3, 0, 1, 1)

        self.lblMediaClases = QLabel(self.grpResumen)
        self.lblMediaClases.setObjectName(u"lblMediaClases")

        self.gridResumen.addWidget(self.lblMediaClases, 3, 1, 1, 1)

        self.lblPesoClases = QLabel(self.grpResumen)
        self.lblPesoClases.setObjectName(u"lblPesoClases")

        self.gridResumen.addWidget(self.lblPesoClases, 3, 2, 1, 1)

        self.lblNombreGlobal = QLabel(self.grpResumen)
        self.lblNombreGlobal.setObjectName(u"lblNombreGlobal")

        self.gridResumen.addWidget(self.lblNombreGlobal, 4, 0, 1, 1)

        self.lblGlobal = QLabel(self.grpResumen)
        self.lblGlobal.setObjectName(u"lblGlobal")

        self.gridResumen.addWidget(self.lblGlobal, 4, 1, 1, 1)


        self.verticalLayout.addWidget(self.grpResumen)

        VentanaPrincipal.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(VentanaPrincipal)
        self.menubar.setObjectName(u"menubar")
        self.menuValora = QMenu(self.menubar)
        self.menuValora.setObjectName(u"menuValora")
        VentanaPrincipal.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(VentanaPrincipal)
        self.statusbar.setObjectName(u"statusbar")
        VentanaPrincipal.setStatusBar(self.statusbar)
#if QT_CONFIG(shortcut)
        self.lblDocente.setBuddy(self.selDocente)
        self.lblMateriales.setBuddy(self.selMateriales)
        self.lblClases.setBuddy(self.selClases)
#endif // QT_CONFIG(shortcut)
        QWidget.setTabOrder(self.selDocente, self.selMateriales)
        QWidget.setTabOrder(self.selMateriales, self.selClases)
        QWidget.setTabOrder(self.selClases, self.btnGuardar)
        QWidget.setTabOrder(self.btnGuardar, self.btnPesos)

        self.menubar.addAction(self.menuValora.menuAction())
        self.menuValora.addAction(self.actionGuardar)
        self.menuValora.addAction(self.actionPesos)
        self.menuValora.addSeparator()
        self.menuValora.addAction(self.actionSalir)

        self.retranslateUi(VentanaPrincipal)

        QMetaObject.connectSlotsByName(VentanaPrincipal)
    # setupUi

    def retranslateUi(self, VentanaPrincipal):
        VentanaPrincipal.setWindowTitle(QCoreApplication.translate("VentanaPrincipal", u"ValoraDI", None))
        self.actionGuardar.setText(QCoreApplication.translate("VentanaPrincipal", u"Guardar valoraci\u00f3n", None))
#if QT_CONFIG(shortcut)
        self.actionGuardar.setShortcut(QCoreApplication.translate("VentanaPrincipal", u"Ctrl+S", None))
#endif // QT_CONFIG(shortcut)
        self.actionPesos.setText(QCoreApplication.translate("VentanaPrincipal", u"Pesos\u2026", None))
#if QT_CONFIG(shortcut)
        self.actionPesos.setShortcut(QCoreApplication.translate("VentanaPrincipal", u"Ctrl+P", None))
#endif // QT_CONFIG(shortcut)
        self.actionSalir.setText(QCoreApplication.translate("VentanaPrincipal", u"Salir", None))
#if QT_CONFIG(shortcut)
        self.actionSalir.setShortcut(QCoreApplication.translate("VentanaPrincipal", u"Ctrl+Q", None))
#endif // QT_CONFIG(shortcut)
        self.grpNueva.setTitle(QCoreApplication.translate("VentanaPrincipal", u"Nueva valoraci\u00f3n", None))
        self.lblDocente.setText(QCoreApplication.translate("VentanaPrincipal", u"&Docente:", None))
#if QT_CONFIG(accessibility)
        self.selDocente.setAccessibleName(QCoreApplication.translate("VentanaPrincipal", u"Nota de docente", None))
#endif // QT_CONFIG(accessibility)
        self.lblMateriales.setText(QCoreApplication.translate("VentanaPrincipal", u"&Materiales:", None))
#if QT_CONFIG(accessibility)
        self.selMateriales.setAccessibleName(QCoreApplication.translate("VentanaPrincipal", u"Nota de materiales", None))
#endif // QT_CONFIG(accessibility)
        self.lblClases.setText(QCoreApplication.translate("VentanaPrincipal", u"&Clases:", None))
#if QT_CONFIG(accessibility)
        self.selClases.setAccessibleName(QCoreApplication.translate("VentanaPrincipal", u"Nota de clases", None))
#endif // QT_CONFIG(accessibility)
#if QT_CONFIG(tooltip)
        self.btnGuardar.setToolTip(QCoreApplication.translate("VentanaPrincipal", u"Guarda la valoraci\u00f3n (Ctrl+S). Se activa cuando las tres categor\u00edas tienen nota", None))
#endif // QT_CONFIG(tooltip)
        self.btnGuardar.setText(QCoreApplication.translate("VentanaPrincipal", u"&Guardar valoraci\u00f3n", None))
        self.grpResumen.setTitle(QCoreApplication.translate("VentanaPrincipal", u"Resumen", None))
        self.lblTotal.setText(QCoreApplication.translate("VentanaPrincipal", u"A\u00fan no hay valoraciones", None))
#if QT_CONFIG(tooltip)
        self.btnPesos.setToolTip(QCoreApplication.translate("VentanaPrincipal", u"Cambia cu\u00e1nto cuenta cada categor\u00eda en la nota global (Ctrl+P)", None))
#endif // QT_CONFIG(tooltip)
        self.btnPesos.setText(QCoreApplication.translate("VentanaPrincipal", u"&Pesos\u2026", None))
        self.lblNombreDocente.setText(QCoreApplication.translate("VentanaPrincipal", u"Docente", None))
        self.lblMediaDocente.setText(QCoreApplication.translate("VentanaPrincipal", u"\u2013", None))
        self.lblPesoDocente.setText(QCoreApplication.translate("VentanaPrincipal", u"peso 40 %", None))
        self.lblNombreMateriales.setText(QCoreApplication.translate("VentanaPrincipal", u"Materiales", None))
        self.lblMediaMateriales.setText(QCoreApplication.translate("VentanaPrincipal", u"\u2013", None))
        self.lblPesoMateriales.setText(QCoreApplication.translate("VentanaPrincipal", u"peso 30 %", None))
        self.lblNombreClases.setText(QCoreApplication.translate("VentanaPrincipal", u"Clases", None))
        self.lblMediaClases.setText(QCoreApplication.translate("VentanaPrincipal", u"\u2013", None))
        self.lblPesoClases.setText(QCoreApplication.translate("VentanaPrincipal", u"peso 30 %", None))
        self.lblNombreGlobal.setStyleSheet(QCoreApplication.translate("VentanaPrincipal", u"font-weight: bold;", None))
        self.lblNombreGlobal.setText(QCoreApplication.translate("VentanaPrincipal", u"Nota global", None))
#if QT_CONFIG(accessibility)
        self.lblGlobal.setAccessibleName(QCoreApplication.translate("VentanaPrincipal", u"Nota global", None))
#endif // QT_CONFIG(accessibility)
        self.lblGlobal.setStyleSheet(QCoreApplication.translate("VentanaPrincipal", u"font-size: 24px; font-weight: bold;", None))
        self.lblGlobal.setText(QCoreApplication.translate("VentanaPrincipal", u"\u2013", None))
        self.menuValora.setTitle(QCoreApplication.translate("VentanaPrincipal", u"&Valoraci\u00f3n", None))
    # retranslateUi

