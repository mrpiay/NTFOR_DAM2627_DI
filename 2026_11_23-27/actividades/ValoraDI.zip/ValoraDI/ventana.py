"""La ventana principal de ValoraDI.

Regla de separación: aquí no hay SQL (está en almacen.py) ni cálculos (están en
modelo.py). La ventana recoge lo que se pulsa, pide el resumen y lo dibuja.
"""
import sqlite3

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QMainWindow, QMessageBox

import almacen
from dialogo_pesos import DialogoPesos
from modelo import CATEGORIAS, Valora, resumir
from ui_ventana import Ui_VentanaPrincipal


class VentanaPrincipal(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_VentanaPrincipal()
        self.ui.setupUi(self)

        # ── Los controles de cada categoría, por su nombre interno ───────
        self.selectores = {
            "docente": self.ui.selDocente,
            "materiales": self.ui.selMateriales,
            "clases": self.ui.selClases,
        }
        self.etiquetas_media = {
            "docente": self.ui.lblMediaDocente,
            "materiales": self.ui.lblMediaMateriales,
            "clases": self.ui.lblMediaClases,
        }
        self.etiquetas_peso = {
            "docente": self.ui.lblPesoDocente,
            "materiales": self.ui.lblPesoMateriales,
            "clases": self.ui.lblPesoClases,
        }

        # ── Conexiones: qué pasa al pulsar cada cosa ─────────────────────
        for selector in self.selectores.values():
            selector.notaCambiada.connect(self.actualizar_guardar)
        self.ui.btnGuardar.clicked.connect(self.guardar)
        self.ui.actionGuardar.triggered.connect(self.guardar)
        self.ui.btnPesos.clicked.connect(self.cambiar_pesos)
        self.ui.actionPesos.triggered.connect(self.cambiar_pesos)
        self.ui.actionSalir.triggered.connect(self.close)

        # ── Al abrir: los pesos guardados y el resumen de lo guardado ────
        self.pesos = self.leer(almacen.leer_pesos)
        self.actualizar_resumen()
        self.ui.selDocente.setFocus()

    # ── El formulario ────────────────────────────────────────────────────
    def actualizar_guardar(self):
        """«Guardar» solo se activa cuando las tres categorías tienen nota."""
        completo = all(s.nota > 0 for s in self.selectores.values())
        self.ui.btnGuardar.setEnabled(completo)
        self.ui.actionGuardar.setEnabled(completo)

    def guardar(self):
        if not self.ui.btnGuardar.isEnabled():
            return
        valora = Valora(*(self.selectores[c].nota for c in CATEGORIAS))
        try:
            almacen.guardar_valora(valora)
        except sqlite3.Error as e:
            QMessageBox.critical(self, "Error", f"No se ha podido guardar la valoración:\n{e}")
            return
        # Formulario vacío para la siguiente persona, y el foco en la primera categoría
        for selector in self.selectores.values():
            selector.limpiar()
        self.ui.selDocente.setFocus()
        self.ui.statusbar.showMessage("Valoración guardada", 3000)
        self.actualizar_resumen()

    # Intro en las estrellas guarda, como al enviar un formulario. (Con el foco en
    # un botón, Intro lo pulsa él mismo: autoDefault, en ventana.ui)
    def keyPressEvent(self, evento):
        if evento.key() in (Qt.Key_Return, Qt.Key_Enter):
            self.guardar()          # si falta alguna nota, guardar() no hace nada
        else:
            super().keyPressEvent(evento)

    # ── Los pesos ────────────────────────────────────────────────────────
    def cambiar_pesos(self):
        dialogo = DialogoPesos(self.pesos, self)
        if dialogo.exec() != DialogoPesos.Accepted:
            return                                  # Cancelar: no cambia nada
        nuevos = dialogo.pesos()
        try:
            almacen.guardar_pesos(nuevos)
        except sqlite3.Error as e:
            QMessageBox.critical(self, "Error", f"No se han podido guardar los pesos:\n{e}")
            return
        self.pesos = nuevos
        self.ui.statusbar.showMessage("Pesos guardados", 3000)
        self.actualizar_resumen()

    # ── El resumen: lo calcula el modelo; aquí solo se dibuja ────────────
    def actualizar_resumen(self):
        valoras = self.leer(almacen.leer_valoras)
        resumen = resumir(valoras, self.pesos)
        self.ui.lblTotal.setText(resumen.texto_total)
        for categoria, fila in zip(CATEGORIAS, resumen.filas):
            self.etiquetas_media[categoria].setText(fila.texto_media)
            self.etiquetas_peso[categoria].setText(f"peso {fila.peso} %")
        self.ui.lblGlobal.setText(resumen.texto_global)

    # ── Leer del almacén avisando si falla ───────────────────────────────
    def leer(self, funcion):
        try:
            return funcion()
        except sqlite3.Error as e:
            QMessageBox.critical(self, "Error", f"No se ha podido leer la base de datos:\n{e}")
            raise SystemExit(1)
