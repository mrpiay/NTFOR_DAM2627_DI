"""Pruebas de la ventana con pytest-qt: el formulario completo, con el teclado.

Ejecuta desde la carpeta del proyecto:  python -m pytest -v
"""
import pytest
from PySide6.QtCore import Qt

import almacen
from ventana import VentanaPrincipal


@pytest.fixture
def ventana(qtbot, tmp_path, monkeypatch):
    # Una base de datos nueva en una carpeta temporal: valora.db no se toca
    monkeypatch.setattr(almacen, "RUTA_BD", tmp_path / "prueba.db")
    almacen.crear_bd()
    v = VentanaPrincipal()
    qtbot.addWidget(v)
    return v


def test_intro_sin_las_tres_notas_no_guarda(ventana, qtbot):
    qtbot.keyClick(ventana.ui.selDocente, Qt.Key_4)
    qtbot.keyClick(ventana.ui.selDocente, Qt.Key_Return)
    assert almacen.leer_valoras() == []


def test_intro_con_las_tres_notas_guarda(ventana, qtbot):
    qtbot.keyClick(ventana.ui.selDocente, Qt.Key_4)
    qtbot.keyClick(ventana.ui.selMateriales, Qt.Key_3)
    qtbot.keyClick(ventana.ui.selClases, Qt.Key_5)
    qtbot.keyClick(ventana.ui.selClases, Qt.Key_Return)
    assert len(almacen.leer_valoras()) == 1
    assert ventana.ui.lblTotal.text() == "1 valoración"
    assert ventana.ui.selDocente.nota == 0          # el formulario se vacía


def test_intro_en_el_boton_guardar(ventana, qtbot):
    for selector in (ventana.ui.selDocente, ventana.ui.selMateriales, ventana.ui.selClases):
        selector.nota = 5
    qtbot.keyClick(ventana.ui.btnGuardar, Qt.Key_Return)
    assert len(almacen.leer_valoras()) == 1
